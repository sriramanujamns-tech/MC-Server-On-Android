#!/bin/bash

mkdir mcserver
cd mcserver

if [ -f "server.jar" ]; then 
	echo -e "\e[33mserver.jar already exists, skipping download\e[0m"
else
	read -p "Enter MCServer jar download url: " url
	wget -O server.jar $url
fi



echo "java -Xmx1024M -Xms1024M -jar server.jar" >> start.sh
chmod +x start.sh
./start.sh

#Accept eula
read -p "You have to accept eula: (y/n) " answer
if [ $answer = "n" ] || [ $answer = "N" ] || [ $answer = "no" ]; then
	echo -e "\e[33mEula not accepted, script exited\e[0m"
	exit
else
	echo "#By changing the setting below to TRUE you are indicating your agreement to our EULA (https://aka.ms/MinecraftEULA).
#Enter date ad time created here (optional)
eula=true" > eula.txt

fi

#choose cracked or not
read -p "Do you want the server to be cracked?: (y/n) " opt
if [ $opt = "y" ] || [ $opt = "Y" ] || [ $opt = "yes" ]; then
	echo "#Minecraft server properties
#Sat Feb 14 16:48:08 IST 2026
accepts-transfers=false
allow-flight=false
broadcast-console-to-ops=true
broadcast-rcon-to-ops=true
bug-report-link=
debug=false
difficulty=easy
enable-code-of-conduct=false
enable-jmx-monitoring=false
enable-query=false
enable-rcon=false
enable-status=true
enforce-secure-profile=true
enforce-whitelist=false
entity-broadcast-range-percentage=100
force-gamemode=false
function-permission-level=2
gamemode=survival
generate-structures=true
generator-settings={}
hardcore=false
hide-online-players=false
initial-disabled-packs=
initial-enabled-packs=vanilla
level-name=world
level-seed=
level-type=minecraft\:normal
log-ips=true
management-server-allowed-origins=
management-server-enabled=false
management-server-host=localhost
management-server-port=0
management-server-secret=QjycA6r5AeimPukU41rJhMsjhrcKNTzb2WvI7M2z
management-server-tls-enabled=true
management-server-tls-keystore=
management-server-tls-keystore-password=
max-chained-neighbor-updates=1000000
max-players=20
max-tick-time=60000
max-world-size=29999984
motd=A Tlauncher friendly Minecraft Server
network-compression-threshold=256
online-mode=false
op-permission-level=4
pause-when-empty-seconds=-1
player-idle-timeout=0
prevent-proxy-connections=false
query.port=25565
rate-limit=0
rcon.password=
rcon.port=25575
region-file-compression=deflate
require-resource-pack=false
resource-pack=
resource-pack-id=
resource-pack-prompt=
resource-pack-sha1=
server-ip=
server-port=25565
simulation-distance=10
spawn-protection=16
status-heartbeat-interval=0
sync-chunk-writes=true
text-filtering-config=
text-filtering-version=0
use-native-transport=true
view-distance=10
white-list=false" > server.properties
else
	echo -e "\e[33mOnline-mode\e[0m"
fi


echo -e "\e[33mCompleted\e[0m"
echo -e "\e[33mStarting MC Server\e[0m"
./start.sh

